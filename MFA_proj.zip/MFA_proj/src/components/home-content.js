import React from "react";

const HomeContent = () => (
  <div className="next-steps">

    <div className="row">
      <div className="col-md-5 mb-4">
        
      </div>

    </div>

    <div className="row">
      

      <div className="col-md" />

      <div className="col-md-5 mb-4">
        
      </div>
    </div>
  </div>
);

export default HomeContent;
